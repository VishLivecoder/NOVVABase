1. Create Table command - primary key must be written in the last column.
