public class Column {
        public String name;
        public Datatypes type;
        public boolean isNull;
}
